/*******************************************************************************
 * @file    nRF24L01.c
 * @author  King
 * @version V1.00
 * @date    16-Sep-2020
 * @brief   ......
 *******************************************************************************
 * @attention
 * 
 * THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
 * CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
 * TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
 * HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
 * CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
 * <H2><CENTER>&COPY; COPYRIGHT 2020 MINDMOTION </CENTER></H2>
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#define __NRF24L01_C__


/* Includes ------------------------------------------------------------------*/
#include "nRF24L01.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/


/* Private macro -------------------------------------------------------------*/
#define nRF24L01_CS_L()  SPI_CSInternalSelected(SPI1, SPI_CS_BIT0, ENABLE)
#define nRF24L01_CS_H()  SPI_CSInternalSelected(SPI1, SPI_CS_BIT0, DISABLE)


/* Private macro -------------------------------------------------------------*/
#define nRF24L01_CE_L()  GPIO_WriteBit(nRF24L01_CE_GPIO, nRF24L01_CE_PIN, Bit_RESET)
#define nRF24L01_CE_H()  GPIO_WriteBit(nRF24L01_CE_GPIO, nRF24L01_CE_PIN, Bit_SET)


/* Private variables ---------------------------------------------------------*/
const uint8_t nRF24L01_RX_ADDR[RX_ADDR_WIDTH] = {0x01, 0x23, 0x45, 0x67, 0x89};
const uint8_t nRF24L01_TX_ADDR[TX_ADDR_WIDTH] = {0x01, 0x23, 0x45, 0x67, 0x89};


/* Private variables ---------------------------------------------------------*/
uint8_t nRF24L01_WorkMode = 0;


/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/* Exported variables --------------------------------------------------------*/
/* Exported function prototypes ----------------------------------------------*/


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void nRF24L01_InitSPI1(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    SPI_InitTypeDef  SPI_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,  ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1,  ENABLE);

    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    SPI_StructInit(&SPI_InitStructure);
    SPI_InitStructure.SPI_Mode              = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize          = SPI_DataSize_8b;
    SPI_InitStructure.SPI_DataWidth         = 8;
    SPI_InitStructure.SPI_CPOL              = SPI_CPOL_Low;
    SPI_InitStructure.SPI_CPHA              = SPI_CPHA_1Edge;
    SPI_InitStructure.SPI_NSS               = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_256;
    SPI_InitStructure.SPI_FirstBit          = SPI_FirstBit_MSB;
    SPI_Init(SPI1, &SPI_InitStructure);

    SPI_Cmd(SPI1, ENABLE);

    SPI_BiDirectionalLineConfig(SPI1, SPI_Direction_Rx);
    SPI_BiDirectionalLineConfig(SPI1, SPI_Direction_Tx);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void nRF24L01_InitGPIO(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
//    EXTI_InitTypeDef EXTI_InitStructure;
//    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB2PeriphClockCmd(nRF24L01_CE_RCC, ENABLE);

    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin   = nRF24L01_CE_PIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
    GPIO_Init(nRF24L01_CE_GPIO, &GPIO_InitStructure);

    RCC_APB2PeriphClockCmd(nRF24L01_IRQ_RCC, ENABLE);

    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin  = nRF24L01_IRQ_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(nRF24L01_IRQ_GPIO, &GPIO_InitStructure);

//    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,  ENABLE);

//    /* PA2 EXTI */
//    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource2);

//    EXTI_InitStructure.EXTI_Line    = EXTI_Line2;
//    EXTI_InitStructure.EXTI_Mode    = EXTI_Mode_Interrupt;
//    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
//    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
//    EXTI_Init(&EXTI_InitStructure);

//    NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;
//    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x02;
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x02;
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//    NVIC_Init(&NVIC_InitStructure);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void EXTI2_IRQHandler(void)
{
    EXTI_ClearITPendingBit(EXTI_Line2);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
uint8_t nRF24L01_SPI_ReadWriteByte(uint8_t Data)
{
    SPI_SendData(SPI1, Data);
    while(!SPI_GetFlagStatus(SPI1, SPI_FLAG_TXEPT));

    while(!SPI_GetFlagStatus(SPI1, SPI_FLAG_RXAVL));
    return SPI_ReceiveData(SPI1);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
uint8_t nRF24L01_ReadREG(uint8_t REG)
{
    uint8_t Data = 0;

    nRF24L01_CS_L();

    nRF24L01_SPI_ReadWriteByte(REG);
    Data = nRF24L01_SPI_ReadWriteByte(Data);

    nRF24L01_CS_H();

    return Data;
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
uint8_t nRF24L01_ReadBuffer(uint8_t REG, uint8_t *Buffer, uint8_t Length)
{
    uint8_t i = 0, Status = 0;

    nRF24L01_CS_L();

    Status = nRF24L01_SPI_ReadWriteByte(REG);

    for(i = 0; i < Length; i++)
    {
        Buffer[i] = nRF24L01_SPI_ReadWriteByte(NOP);
    }

    nRF24L01_CS_H();

    return Status;
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
uint8_t nRF24L01_WriteREG(uint8_t REG, uint8_t Data)
{
    uint8_t Status = 0;

    nRF24L01_CS_L();

    Status = nRF24L01_SPI_ReadWriteByte(REG);
    nRF24L01_SPI_ReadWriteByte(Data);

    nRF24L01_CS_H();

    return Status;
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
uint8_t nRF24L01_WriteBuffer(uint8_t REG, uint8_t *Buffer, uint8_t Length)
{
    uint8_t i = 0, Status = 0;

    nRF24L01_CS_L();

    Status = nRF24L01_SPI_ReadWriteByte(REG);

    for(i = 0; i < Length; i++)
    {
        nRF24L01_SPI_ReadWriteByte(Buffer[i]);
    }

    nRF24L01_CS_H();

    return Status;
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
uint8_t nRF24L01_CheckStatus(void)
{
    uint8_t WriteBuffer[5] = {0x01, 0x23, 0x45, 0x67, 0x89};
    uint8_t ReadBuffer[5]  = {0x00, 0x00, 0x00, 0x00, 0x00};

    uint8_t i = 0;

    nRF24L01_WriteBuffer(W_REGISTER | TX_ADDR, WriteBuffer, sizeof(WriteBuffer));
    nRF24L01_ReadBuffer(R_REGISTER  | TX_ADDR, ReadBuffer,  sizeof(ReadBuffer));

    for(i = 0; i < 5; i++)
    {
        if(WriteBuffer[i] != ReadBuffer[i])
        {
            return 0;
        }
    }

    return 1;
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void nRF24L01_EnterRxMode(void)
{
    nRF24L01_CE_L();

    nRF24L01_WriteBuffer(W_REGISTER | RX_ADDR_P0, (uint8_t *)nRF24L01_RX_ADDR, RX_ADDR_WIDTH);

    /* ����ͨ��0�Զ�Ӧ������ */
    nRF24L01_WriteREG(W_REGISTER | EN_AA,     0x01);
    /* ��������ͨ��0���� */
    nRF24L01_WriteREG(W_REGISTER | EN_RXADDR, 0x01);
    /* ����nRF24L01����ͨ��Ƶ�� */
    nRF24L01_WriteREG(W_REGISTER | RF_CH,     40);
    /* ��������ͨ��0��Ч���ݿ���: 32�ֽ� */
    nRF24L01_WriteREG(W_REGISTER | RX_PW_P0,  RX_PAYLOAD_WIDTH);
    /* ��Ƶ����: 0dBm���书��, 2Mbps���ݴ�����, �����������Ŵ������� */
    nRF24L01_WriteREG(W_REGISTER | RF_SETUP,  0x0F);
    /* �ϵ����ģʽ, ʹ��16λCRCУ�� */
    nRF24L01_WriteREG(W_REGISTER | CONFIG,    0x0F);

    nRF24L01_CE_H();
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void nRF24L01_EnterTxMode(void)
{
    nRF24L01_CE_L();

    nRF24L01_WriteBuffer(W_REGISTER | TX_ADDR,    (uint8_t *)nRF24L01_TX_ADDR, TX_ADDR_WIDTH);
    nRF24L01_WriteBuffer(W_REGISTER | RX_ADDR_P0, (uint8_t *)nRF24L01_RX_ADDR, RX_ADDR_WIDTH);

    /* ����ͨ��0�Զ�Ӧ������ */
    nRF24L01_WriteREG(W_REGISTER | EN_AA,      0x01);
    /* ��������ͨ��0���� */
    nRF24L01_WriteREG(W_REGISTER | EN_RXADDR,  0x01);
    /* �Զ��ط���ʱΪ500+86us, �Զ��ط�10�� */
    nRF24L01_WriteREG(W_REGISTER | SETUP_RETR, 0x1A);
    /* ����nRF24L01����ͨ��Ƶ�� */
    nRF24L01_WriteREG(W_REGISTER | RF_CH,      40);
    /* ��Ƶ����: 0dBm���书��, 2Mbps���ݴ�����, �����������Ŵ������� */
    nRF24L01_WriteREG(W_REGISTER | RF_SETUP,   0x0F);
    /* �ϵ緢��ģʽ, ʹ��16λCRCУ�� */
    nRF24L01_WriteREG(W_REGISTER | CONFIG,     0x0E);

    nRF24L01_CE_H();
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
uint8_t nRF24L01_RxPacket(uint8_t *Buffer)
{
    uint8_t Status = 0;

    /* ��ȡ״̬�Ĵ�����ֵ, �������Ӧ״̬λ */
    Status = nRF24L01_ReadREG(R_REGISTER | STATUS);
    nRF24L01_WriteREG(W_REGISTER | STATUS, Status);

    if(Status & RX_DR)  /* ���յ����� */
    {
        /* ��ȡ���� */
        nRF24L01_ReadBuffer(R_RX_PAYLOAD, Buffer, RX_PAYLOAD_WIDTH);
        /* ���RX FIFO�Ĵ���, Ӧ���ڽ���ģʽ�� */
        nRF24L01_WriteREG(FLUSH_RX, 0xFF);

        return RX_DR;
    }
    else
    {
        return 0;
    }
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
uint8_t nRF24L01_TxPacket(uint8_t *Buffer)
{
    uint8_t Status = 0;

    nRF24L01_CE_L();
    /* д������ */
    nRF24L01_WriteBuffer(W_TX_PAYLOAD, Buffer, TX_PAYLOAD_WIDTH);
    nRF24L01_CE_H();

    /* �ȴ�������� */
    while(GPIO_ReadInputDataBit(nRF24L01_IRQ_GPIO, nRF24L01_IRQ_PIN));

    /* ��ȡ״̬�Ĵ�����ֵ, �������Ӧ״̬λ */
    Status = nRF24L01_ReadREG(R_REGISTER | STATUS);
    nRF24L01_WriteREG(W_REGISTER | STATUS, Status);

    if(Status & MAX_RT)     /* �ﵽ����ط����� */
    {
        /* ���TX FIFO�Ĵ���, Ӧ���ڷ���ģʽ�� */
        nRF24L01_WriteREG(FLUSH_TX, 0xFF);
        return MAX_RT;
    }
    else if(Status & TX_DS) /* ������� */
    {
        return TX_DS;
    }
    else                    /* ����ʧ�� */
    {
        return 0;
    }
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void nRF24L01_Init(void)
{
    nRF24L01_InitGPIO();

    nRF24L01_CE_H();

    nRF24L01_InitSPI1();

    if(nRF24L01_CheckStatus())
    {
        printf("\r\nnRF24L01 Online!\r\n");

        TASK_Append(TASK_ID_2G4, nRF24L01_Handler, 100);
    }
    else
    {
        printf("\r\nnRF24L01 Offline!!!\r\n");
    }    
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void nRF24L01_Configure(uint8_t Mode)
{
    nRF24L01_WorkMode = Mode;

    if(nRF24L01_WorkMode == 1)      /* �������ģʽ */
    {
        nRF24L01_EnterRxMode();
    }
    else if(nRF24L01_WorkMode == 2) /* ���뷢��ģʽ */
    {
        nRF24L01_EnterTxMode();
    }
    else
    {
        nRF24L01_WorkMode = 0;
    }
}
SHELL_EXPORT_CMD(mode, nRF24L01_Configure, Configure nRF24L01 Work Mode);


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void nRF24L01_Handler(void)
{
    static uint8_t TxTick = 0;

    uint8_t i = 0;
    uint8_t RxBuffer[RX_PAYLOAD_WIDTH];
    uint8_t TxBuffer[TX_PAYLOAD_WIDTH];

    if(nRF24L01_WorkMode == 1)      /* ����ģʽ���� */
    {
        if(nRF24L01_RxPacket(RxBuffer) != 0)
        {
            for(i = 0; i < RX_PAYLOAD_WIDTH; i++)
            {
                printf("0x%02x ", RxBuffer[i]);
                if((i % 10) == 0) printf("\r\n");
            }
        }
    }
    else if(nRF24L01_WorkMode == 2) /* ����ģʽ���� */
    {
        TxTick++;

        if(TxTick == 20)
        {
            TxTick = 0;

            for(i = 0; i < TX_PAYLOAD_WIDTH; i++)
            {
                TxBuffer[i] = i;
            }

            nRF24L01_TxPacket(TxBuffer);

            printf("\r\nnRF24L01 Tx OK");
        }
    }
    else
    {
    }
}


/******************* (C) COPYRIGHT 2020 *************************END OF FILE***/

