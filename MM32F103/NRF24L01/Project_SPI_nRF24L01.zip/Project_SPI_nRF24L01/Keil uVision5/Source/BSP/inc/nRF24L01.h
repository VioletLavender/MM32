/*******************************************************************************
 * @file    nRF24L01.h
 * @author  King
 * @version V1.00
 * @date    16-Sep-2020
 * @brief   ......
 *******************************************************************************
 * @attention
 * 
 * THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
 * CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
 * TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
 * HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
 * CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
 * <H2><CENTER>&COPY; COPYRIGHT 2020 MINDMOTION </CENTER></H2>
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __NRF24L01_H__
#define __NRF24L01_H__


#ifdef __cplusplus
extern "C" {
#endif


#undef  EXTERN

#ifdef  __NRF24L01_C__
#define EXTERN
#else
#define EXTERN extern
#endif


/* Includes ------------------------------------------------------------------*/
#include "config.h"


/* Exported constants --------------------------------------------------------*/
#define nRF24L01_CE_RCC     RCC_APB2Periph_GPIOA
#define nRF24L01_CE_GPIO    GPIOA
#define nRF24L01_CE_PIN     GPIO_Pin_3

#define nRF24L01_IRQ_RCC    RCC_APB2Periph_GPIOA
#define nRF24L01_IRQ_GPIO   GPIOA
#define nRF24L01_IRQ_PIN    GPIO_Pin_2


/* Exported constants --------------------------------------------------------*/
#define R_REGISTER          0x00
#define W_REGISTER          0x20
#define R_RX_PAYLOAD        0x61
#define W_TX_PAYLOAD        0xA0
#define FLUSH_TX            0xE1
#define FLUSH_RX            0xE2
#define REUSE_TX_PL         0xE3
#define NOP                 0xFF


/* Exported constants --------------------------------------------------------*/
#define CONFIG              0x00
#define EN_AA               0x01
#define EN_RXADDR           0x02
#define SETUP_AW            0x03
#define SETUP_RETR          0x04
#define RF_CH               0x05
#define RF_SETUP            0x06
#define STATUS              0x07
#define     RX_DR           0x40
#define     TX_DS           0x20
#define     MAX_RT          0x10
#define OBSERVE_TX          0x08
#define CD                  0x09
#define RX_ADDR_P0          0x0A
#define RX_ADDR_P1          0x0B
#define RX_ADDR_P2          0x0C
#define RX_ADDR_P3          0x0D
#define RX_ADDR_P4          0x0E
#define RX_ADDR_P5          0x0F
#define TX_ADDR             0x10
#define RX_PW_P0            0x11
#define RX_PW_P1            0x12
#define RX_PW_P2            0x13
#define RX_PW_P3            0x14
#define RX_PW_P4            0x15
#define RX_PW_P5            0x16
#define FIFO_STATUS         0x17


/* Exported constants --------------------------------------------------------*/
#define RX_ADDR_WIDTH       0x05
#define TX_ADDR_WIDTH       0x05

#define RX_PAYLOAD_WIDTH    0x20
#define TX_PAYLOAD_WIDTH    0x20


/* Exported types ------------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/


/* Exported functions --------------------------------------------------------*/
EXTERN void nRF24L01_EnterRxMode(void);
EXTERN void nRF24L01_EnterTxMode(void);
EXTERN uint8_t nRF24L01_RxPacket(uint8_t *Buffer);
EXTERN uint8_t nRF24L01_TxPacket(uint8_t *Buffer);
EXTERN void nRF24L01_Init(void);
EXTERN void nRF24L01_Handler(void);


#ifdef __cplusplus
}
#endif


#endif


/******************* (C) COPYRIGHT 2020 *************************END OF FILE***/

