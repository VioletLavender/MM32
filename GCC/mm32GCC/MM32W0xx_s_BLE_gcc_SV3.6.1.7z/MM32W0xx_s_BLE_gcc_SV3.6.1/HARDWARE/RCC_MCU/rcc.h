#ifndef __RCC_H__
#define __RCC_H__

void SystemClk_HSEInit(void);
void SysClk8to48(void);
void SysClk48to8(void);
#endif
