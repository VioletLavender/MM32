#ifndef __SYS_H
#define __SYS_H

#include "HAL_conf.h"
#include "HAL_device.h"
#include "stdio.h"
#include "dtype.h"

void SysTick_Configuration(void);

#endif





























