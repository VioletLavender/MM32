
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'MM32SPIN2xxDemo' 
 * Target:  'SPIN27Demo' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


#endif /* RTE_COMPONENTS_H */
