#include "uart.h" 

#define GPIO_PORT(n) ((GPIO_TypeDef *) (GPIOA_BASE + n*0x400))

#define DEBUG_UART UART1

#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif 

#ifdef USE_IAR
PUTCHAR_PROTOTYPE
{
	while((DEBUG_UART->CSR&UART_IT_TXIEN)==0);
	DEBUG_UART->TDR = (ch & (uint16_t)0x00FF);      
	return ch;
}
#else
#pragma import(__use_no_semihosting)             
            
struct __FILE 
{ 
	int handle; 
}; 

FILE __stdout;       

void _sys_exit(int x) 
{ 
	x = x; 
} 

int fputc(int ch, FILE *f)
{      
	while((DEBUG_UART->CSR&UART_IT_TXIEN)==0);
	DEBUG_UART->TDR = (ch & (uint16_t)0x00FF);      
	return ch;
}
#endif
/**
* @brief  This function will initialize the UART.
* @param bound: Configuring UART baud rate.
* @param index: GPIO pin and multiplexing options
	bit 0-3: Port chose
	bit 4-7: Pin & Remap 
	According to the data UartTX & UartRX
* @retval : None
*/
u8 UartTX[] = {0x91, 0xa3, 0x60, 0x21};//PA9/PA10/PB8/PA2
u8 UartRX[] = {0xa1, 0x93, 0x70, 0x31};//PA10/PA9/PB7/PA3

void uart_initwBaudRate(u32 bound,u8 index)
{
    u8 *uartrx,*uarttx;
    u8 idx,port,rx_pin,rx_afio,tx_pin,tx_afio;
    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;
    uarttx = UartTX;
    uartrx = UartRX;
    idx = (index&0xf0) >> 4;
    port = index & 0x7;
    tx_afio = uarttx[idx]&0x7;
    rx_afio = uartrx[idx]&0x7;
    tx_pin = (uarttx[idx]&0xf0) >> 4;
    rx_pin = (uartrx[idx]&0xf0) >> 4;

    if(idx < 3)
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);
    else
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART2, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA << port, ENABLE);

    GPIO_PinAFConfig(GPIO_PORT(port),tx_pin,tx_afio);
    GPIO_PinAFConfig(GPIO_PORT(port),rx_pin,rx_afio);

    UART_InitStructure.UART_BaudRate = bound;
    UART_InitStructure.UART_WordLength = UART_WordLength_8b;
    UART_InitStructure.UART_StopBits = UART_StopBits_1;
    UART_InitStructure.UART_Parity = UART_Parity_No;
    UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None;
    UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;	

    UART_Init(DEBUG_UART, &UART_InitStructure);
    //UART_TXInit
    GPIO_InitStructure.GPIO_Pin = 1 << tx_pin;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	
    GPIO_Init(GPIO_PORT(port), &GPIO_InitStructure);
    //UART_RXInit
    GPIO_InitStructure.GPIO_Pin = 1 << rx_pin;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIO_PORT(port), &GPIO_InitStructure); 

    UART_Cmd(DEBUG_UART, ENABLE); 
}

void Uart1_Init(uint32_t wBaudRrate)
{
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    GPIO_PinAFConfig(GPIOB,GPIO_PinSource8, GPIO_AF_0);
    GPIO_PinAFConfig(GPIOB,GPIO_PinSource9, GPIO_AF_0);
//    do {
//        NVIC_InitTypeDef NVIC_InitStruct;

//        NVIC_InitStruct.NVIC_IRQChannel = UART1_IRQn;
//        NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
//        NVIC_InitStruct.NVIC_IRQChannelPriority = 2;
//        NVIC_Init(& NVIC_InitStruct);
//    } while(0);
    
    do {
        UART_InitTypeDef UART_InitStructure;
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);
        UART_InitStructure.UART_BaudRate = wBaudRrate;
        UART_InitStructure.UART_WordLength = UART_WordLength_8b;
        UART_InitStructure.UART_StopBits = UART_StopBits_1;
        UART_InitStructure.UART_Parity = UART_Parity_No;
        UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None;
        UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;	
        UART_Init(UART1, &UART_InitStructure);
        
//        UART_ITConfig(UART1, UART_IT_RXIEN, ENABLE);
//        UART_ClearITPendingBit(UART1,UART_IT_RXIEN);
        UART_Cmd(UART1, ENABLE);
    } while(0);
    
    do {
        GPIO_InitTypeDef GPIO_InitStructure;
        //UART_TXInit
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        //UART_RXInit
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
    } while(0);
}
/**
* @brief  This function will send a character.
* @param ch: This character will be sent.
* @retval : None
*/
void Uart_PutChar (char ch)
{
	while((DEBUG_UART->CSR&UART_IT_TXIEN)==0);
	DEBUG_UART->TDR = (ch & (uint16_t)0x00FF);    
}
/**
* @brief  This function will send a string.
* @param buff: The string of this address will be sent.
* @param len: The length of the string to be sent.
* @retval : None
*/
void Uart_PutBuff (uint8_t *buff, uint32_t len)
{
	while(len--)
	{
		Uart_PutChar(*buff);
		buff++;
	}
}
/**
* @brief  VCAN Uart serial port assistant interface function.
* @param wareaddr: The array data address to be sent.
* @param waresize: The size of the array data to be sent.
* @retval : None
*/
void Send_Ware(void *wareaddr, uint32_t waresize)
{
#define CMD_WARE     3
	uint8_t cmdf[2] = {CMD_WARE, ~CMD_WARE};
	uint8_t cmdr[2] = {~CMD_WARE, CMD_WARE};

	Uart_PutBuff(cmdf, sizeof(cmdf));
	Uart_PutBuff((uint8_t *)wareaddr, waresize);
	Uart_PutBuff(cmdr, sizeof(cmdr));
}
/*! \brief serial out a byte
 *! \param chByte Bytes to be sent
 *! \return true or false
 */
bool serial_out(uint8_t chByte)
{
    if ((UART1 ->CSR & ((uint16_t)0x0001)) != 0) {
        UART1 ->TDR = (chByte & (uint16_t)0x00FF);      
        return true;
    }
    return false;
}
/*! \brief serial in a byte
 *! \param pchByte Byte Pointers
 *! \return true or false
 */
bool serial_in(uint8_t *pchByte)
{
    if (pchByte != NULL) {
        if ((UART1 ->CSR & ((uint16_t)0x0002)) != 0) {
            *pchByte = UART1 ->RDR & (uint8_t)0xFF;
            return true;
        }
    }
    return false;
}

bool print_str_init(print_str_t* ptPRN,char* pchString)
{
    if (ptPRN != NULL && pchString != NULL) {
        ptPRN->chStates = 0;
        ptPRN->pchString = pchString;
        return true;
    }
    return false;
}

#define PRINT_STRING_RESET_FSM() \
do {\
    ptPRN->chStates = START;\
} while(0)

fsm_rt_t print_string(print_str_t *ptPRN)
{
    enum {
        START = 0,
        CHECK_EMPTY,
        PRINT_ON
    };
    if (ptPRN == NULL) {
        return fsm_rt_err;
    }
    switch (ptPRN->chStates ) {
        case START:
            ptPRN->chStates = CHECK_EMPTY;
            //break;
        case CHECK_EMPTY:
            if ('\0' == *ptPRN->pchString) {
                PRINT_STRING_RESET_FSM();
                return fsm_rt_cpl;
            } else {
                ptPRN->chStates = PRINT_ON;
            }
            //break;
        case PRINT_ON:
            if (serial_out(*ptPRN->pchString)) {
                ptPRN->pchString ++;
                ptPRN->chStates = CHECK_EMPTY;
            }
    }
    return fsm_rt_on_going;
 }

bool check_str_init(check_str_t* ptCHK,char* pchString)
{
    if (ptCHK != NULL && pchString != NULL) {
        ptCHK->chStates = 0;
        ptCHK->pchFirByte = pchString;
        return true;
    }
    return false;
}

#define CHECK_STRING_RESET_FSM() \
do {\
    ptCHK->chStates = START;\
} while(0)
fsm_rt_t check_string(check_str_t *ptCHK)
{
    enum {
        START = 0,
        CHECK_EMPTY,
        RECEIVE,
        CHECK_ON
    };
    if (ptCHK == NULL) {
        return fsm_rt_err;
    }

    switch (ptCHK->chStates) {
        case START:
            ptCHK->pchString = ptCHK->pchFirByte;
            ptCHK->chStates = CHECK_EMPTY;
            //break;
        case CHECK_EMPTY:
            if ('\0' == *ptCHK->pchString) {
                CHECK_STRING_RESET_FSM();
                return fsm_rt_cpl;
            } else {
                ptCHK->chStates = RECEIVE;
            }
            //break;
        case RECEIVE:
            if (serial_in(&ptCHK->chByte)) {
                ptCHK->chStates = CHECK_ON;
            } else {
                break;
            }
            //break;
        case CHECK_ON:
            if (*ptCHK->pchString == ptCHK->chByte) {
                ptCHK->pchString ++;
                ptCHK->chStates = CHECK_EMPTY;
            } else {
                if (*ptCHK->pchFirByte == ptCHK->chByte) {
                    ptCHK->pchString = ptCHK->pchFirByte + 1;
                    ptCHK->chStates = CHECK_EMPTY;
                    return fsm_rt_err;
                } else {
                    CHECK_STRING_RESET_FSM();
                    return fsm_rt_err;
                }
            }
    }
    return fsm_rt_on_going;
}
