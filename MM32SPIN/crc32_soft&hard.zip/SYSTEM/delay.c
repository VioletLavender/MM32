#include "delay.h"

#define USE_SYSTICK_DELAY 1

#if USE_SYSTICK_DELAY

extern u32 SystemCoreClock;

static u32	fac_us=0;							//us Time delay multiplier
static u32	fac_ms=0;							//ms Time delay multiplier
/**
* @brief  This function will be used to initialize SysTick.
* @param : None
* @retval : None
*/
void delay_init()
{
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK);	//Select external clock HCLK
	fac_us = SystemCoreClock/1000000;				//1/8 of the system clock
	fac_ms = (u16)fac_us*1000;					//Represents the number of systick clocks required for each ms
}
/**
* @brief  Use SysTick as the us delay function.
* @param nus: Setting the us delay time.
* @retval : None
*/
void delay_us(__IO uint32_t nus)
{
	u32 temp;
	SysTick ->LOAD = nus*fac_us; 					//Time loading
	SysTick ->VAL = 0x00;        					//Empty counter
	SysTick ->CTRL |= SysTick_CTRL_ENABLE_Msk ;	//Start counting down
	do
	{
		temp = SysTick ->CTRL;
	}while((temp&0x01) && !(temp&(1<<16)));		//Waiting time to arrive
	SysTick ->CTRL &= ~SysTick_CTRL_ENABLE_Msk;	//Close counter
	SysTick ->VAL = 0X00;      					//Empty counter
}
/**
* @brief  Use SysTick as the us delay function.
* @param nms: Setting the ms delay time.
	Note the range of nms
	SysTick->LOAD is a 24-bit register, so the maximum delay is:
	nms<=0xffffff*1000/SYSCLK
	SYSCLK unit is Hz, nms is in ms
	For 48M  HCLK conditions, nms<=349
* @retval : None
*/
void delay_ms(__IO uint32_t nms)
{
	u32 temp;
	SysTick ->LOAD = (u32)nms*fac_ms;				//Time loading(SysTick->LOADΪ24bit)
	SysTick ->VAL = 0x00;							//Empty counter
	SysTick ->CTRL |= SysTick_CTRL_ENABLE_Msk ;	///Start counting down  
	do
	{
		temp = SysTick ->CTRL;
	}while((temp&0x01) && !(temp&(1<<16)));		//Waiting time to arrive   
	SysTick ->CTRL &= ~SysTick_CTRL_ENABLE_Msk;	//Close counter
	SysTick ->VAL = 0X00;       					//Empty counter	  	    
}
#else

void delay_us(__IO uint32_t nus)
{
	u16 i = 0;
	while(nus--)
	{
		i = 10;
		while(i--);
	}
}

void delay_ms(__IO uint32_t nms)
{
	u32 i = 0;
	while(nms--)
	{
		i = 3100;
		while(i--);
	}
}
#endif

