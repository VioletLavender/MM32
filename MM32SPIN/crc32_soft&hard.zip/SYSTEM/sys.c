#include "sys.h"

void System_Clock_Init(u8 PLL)
{ 
}	



