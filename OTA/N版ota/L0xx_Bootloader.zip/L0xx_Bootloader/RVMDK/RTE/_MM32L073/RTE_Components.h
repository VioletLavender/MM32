
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'L0xx_Bootloader' 
 * Target:  'MM32L073' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "HAL_device.h"



#endif /* RTE_COMPONENTS_H */
